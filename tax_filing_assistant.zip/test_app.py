def test_basic():
    assert 1 + 1 == 2
